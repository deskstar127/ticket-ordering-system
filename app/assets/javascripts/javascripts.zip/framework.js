// load assorted libs
//= require modernizr
//= require jquery
//= require lodash
//= require moment
//= require medium-editor




// load angular libs
//= require angular
//= require_tree ./lib
//= require_tree ./anz_js
//= require angularjs/rails/resource
//= require restangular
//= require angular-moment
//= require angular-ui-router
//= require angular-animate
//= require angular-sanitize
//= require angular-bootstrap
//= require angular-local-storage
//= require angular-rails-templates
//= require angular-ui-utils
//= require angular-localforage
//= require ng-file-upload/angular-file-upload
//= require ng-file-upload/angular-file-upload-html5-shim
