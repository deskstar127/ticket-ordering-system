//angular.module('thms.directives').directive('dateFix', function() {
//  return {
//    restrict: 'A',
//    require: 'ngModel',
//    link: function (scope, element, attr, ngModel) {
//      element.on('change', function() {
//        scope.$apply(function () {
//          ngModel.$setViewValue(element.val());
//        });
//      });
//    }
//  };
//});