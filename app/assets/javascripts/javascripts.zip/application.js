//= require_tree ../templates

// load the application
//= require base_controller
//= require angular-init
//= require app-run
//= require_tree ./modules
//= require_tree ./controllers
//= require_tree ./directives
//= require_tree ./services
