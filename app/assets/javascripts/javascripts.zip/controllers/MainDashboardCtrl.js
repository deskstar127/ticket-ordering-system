angular.module('thms.controllers').controller('MainDashboardCtrl', ['$rootScope', function($rootScope) {

}]);